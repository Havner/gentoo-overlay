---
layout: home
---

<script setup>
import Showcases from './Showcases.vue'
</script>

<Showcases />
