export { default as default } from "../vitepress.config"
