import DefaultTheme from "vitepress/theme"
import "../../vitepress.theme.css"
import "devicon/devicon.min.css"
import "font-logos/assets/font-logos.css"

export default DefaultTheme
