# Higher Level Libraries

Do not use these, they will be removed before the first release.

GJS code moved to <https://github.com/aylur/gnim/>
Lua moved to <https://github.com/tokyob0t/astal-lua>
