# Astal

Astal is a collection of libraries written in Vala and C, designed to serve as
the foundation for both lightweight widgets and fully-featured desktop shells.
It handles the backend logic, so you can focus entirely on building the
frontend.

To get started read the [wiki](https://aylur.github.io/astal/)
