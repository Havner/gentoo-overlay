---
name: Question
about: Ask a question or ask for help
title: ''
labels: question
assignees: ''

---

**Have you read through the documentation?**
- [ ] [Astal docs](https://aylur.github.io/astal/)
- [ ] [Library references](https://aylur.github.io/astal/guide/libraries/references)
- [ ] [FAQ](https://aylur.github.io/astal/guide/typescript/faq)

**Describe what have you tried so far**
A description or example code of what you have got so far.

**Describe your question**
A question.
