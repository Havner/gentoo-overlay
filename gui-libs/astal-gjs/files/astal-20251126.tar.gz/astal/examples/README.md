# Examples

These are examples written in Vala, Python (PyGObject) and TypeScript (GJS)
intended to show you how to write a Gtk application from scratch using
gtk-layer-shell and Astal.

> [!IMPORTANT]
> If you are interested in using AGS, I don't recommend these examples, but
> instead have a look at [AGS examples](https://github.com/Aylur/ags/tree/main/examples).
