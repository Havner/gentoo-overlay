# Simple Bar Example

![simple-bar](https://github.com/user-attachments/assets/a306c864-56b7-44c4-8820-81f424f32b9b)

A simple bar for Hyprland using

- [Battery library](https://aylur.github.io/astal/guide/libraries/battery).
- [Hyprland library](https://aylur.github.io/astal/guide/libraries/hyprland).
- [Mpris library](https://aylur.github.io/astal/guide/libraries/mpris).
- [Network library](https://aylur.github.io/astal/guide/libraries/network).
- [Tray library](https://aylur.github.io/astal/guide/libraries/tray).
- [WirePlumber library](https://aylur.github.io/astal/guide/libraries/wireplumber).
- [dart-sass](https://sass-lang.com/dart-sass/) as the css precompiler
