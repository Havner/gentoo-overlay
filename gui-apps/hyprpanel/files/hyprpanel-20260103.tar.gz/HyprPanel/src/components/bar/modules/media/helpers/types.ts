export type MediaTags = {
    title: string;
    artists: string;
    artist: string;
    album: string;
    name: string;
    identity: string;
};
