import Separator from 'src/components/shared/Separator';

export const ModuleSeparator = (): JSX.Element => {
    return <Separator className={'bar-module-separator'} />;
};
