export interface RevealerSetupBindings {
    cleanup: () => void;
}
