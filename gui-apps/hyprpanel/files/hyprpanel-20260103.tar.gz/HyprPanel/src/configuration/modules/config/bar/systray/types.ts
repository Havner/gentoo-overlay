export type SystrayIconMap = {
    [key: string]: {
        icon: string;
        color: string;
        size: string;
    };
};
