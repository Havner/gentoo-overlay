import { opt } from 'src/lib/options';

export default {
    raiseMaximumVolume: opt(false),
};
