import { opt } from 'src/lib/options';

export default {
    show_total: opt(false),
    hideCountWhenZero: opt(false),
    rightClick: opt(''),
    middleClick: opt(''),
    scrollUp: opt(''),
    scrollDown: opt(''),
};
