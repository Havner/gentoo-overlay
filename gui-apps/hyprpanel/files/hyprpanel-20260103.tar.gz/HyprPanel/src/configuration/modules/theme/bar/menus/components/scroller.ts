import { opt } from 'src/lib/options';

export default {
    radius: opt('0.7em'),
    width: opt('0.25em'),
};
