export type Config = {
    [key: string]: string | number | boolean | object;
};
