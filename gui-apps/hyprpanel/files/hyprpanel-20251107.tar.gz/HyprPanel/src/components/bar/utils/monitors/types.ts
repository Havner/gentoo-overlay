export interface MonitorMapping {
    gdkIndex: number;
    hyprlandId: number;
}
