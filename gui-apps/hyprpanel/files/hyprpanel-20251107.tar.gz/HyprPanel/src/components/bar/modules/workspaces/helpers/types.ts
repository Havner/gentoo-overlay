import { ApplicationIcons } from '../types';

export type AppIconOptions = {
    iconMap: ApplicationIcons;
    defaultIcon: string;
    emptyIcon: string;
};
