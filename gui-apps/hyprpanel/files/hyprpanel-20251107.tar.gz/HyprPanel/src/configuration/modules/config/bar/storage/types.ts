import { SizeUnit } from 'src/lib/units/size/types';

export type StorageUnit = SizeUnit | 'auto';
