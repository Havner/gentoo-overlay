export type Action = 'sleep' | 'reboot' | 'logout' | 'shutdown';
