export type ProfileType = 'balanced' | 'power-saver' | 'performance';
