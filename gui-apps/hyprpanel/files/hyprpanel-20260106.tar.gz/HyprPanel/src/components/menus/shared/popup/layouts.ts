export const POPUP_LAYOUTS: string[] = [
    'center',
    'top',
    'top-right',
    'top-center',
    'top-left',
    'bottom-left',
    'bottom-center',
    'bottom-right',
];
